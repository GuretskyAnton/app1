from datetime import datetime, timedelta
from app import db

class List(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), nullable=False)
    items = db.relationship('Item', backref='list', cascade='all, delete-orphan')

class Item(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), nullable=False)
    list_id = db.Column(db.Integer, db.ForeignKey('list.id'), nullable=False)
    locked_until = db.Column(db.DateTime)
    values = db.relationship('Value', backref='item', cascade='all, delete-orphan')

class Value(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)  # Text вместо String для больших текстов
    item_id = db.Column(db.Integer, db.ForeignKey('item.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)