from flask import Blueprint, render_template, request, redirect, url_for, flash
from app.models import List, db

lists_bp = Blueprint('lists', __name__)

@lists_bp.route('/', methods=['GET'])
def index():
    lists = List.query.all()
    return render_template('index.html', lists=lists)

@lists_bp.route('/check_db')
def check_db():
    try:
        db.session.execute('SELECT 1')
        return "Подключение к БД работает!!!"
    except Exception as e:
        return f"Ошибка подключения: {str(e)}", 500

@lists_bp.route('/list/create', methods=['POST'])
def create_list():
    name = request.form.get('name')
    if name:
        new_list = List(name=name)
        db.session.add(new_list)
        db.session.commit()
        flash(f'Список "{new_list.name}" успешно создан', 'success')
    return redirect(url_for('lists.index'))

@lists_bp.route('/list/delete/<int:list_id>', methods=['POST'])
def delete_list(list_id):
    lst = List.query.get_or_404(list_id)
    if lst.items:
        flash(f'Нельзя удалить список "{lst.name}" с объектами', 'error')
    else:
        db.session.delete(lst)
        db.session.commit()
        flash(f'Список "{lst.name}" успешно удален', 'success')
    return redirect(url_for('lists.index'))

@lists_bp.route('/list/<int:list_id>')
def view_list(list_id):
    lst = List.query.get_or_404(list_id)
    return render_template('list.html', lst=lst)