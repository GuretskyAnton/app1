from flask import Blueprint, request, redirect, url_for, flash, render_template
from datetime import datetime, timedelta
from app.models import Item, Value, db

items_bp = Blueprint('items', __name__)

@items_bp.route('/list/<int:list_id>/item', methods=['POST'])
def add_item(list_id):
    """Создание нового объекта (ключа)"""
    name = request.form.get('name')
    if name:
        new_item = Item(name=name, list_id=list_id)
        db.session.add(new_item)
        db.session.commit()
        flash(f'Объект "{new_item.name}" успешно создан', 'success')
    return redirect(url_for('lists.view_list', list_id=list_id))

@items_bp.route('/item/<int:item_id>/add_values', methods=['POST'])
def add_values(item_id):
    """Добавление нескольких значений через запятую"""
    item = Item.query.get_or_404(item_id)
    values_text = request.form.get('values_text', '').strip()
    
    if values_text:
        # Разделяем значения по запятым и очищаем от пробелов
        values_list = [v.strip() for v in values_text.split(',') if v.strip()]
        
        # Добавляем каждое значение в базу
        for value_content in values_list:
            new_value = Value(content=value_content, item_id=item_id)
            db.session.add(new_value)
        
        db.session.commit()
        flash(f'Добавлено {len(values_list)} значений', 'success')
    else:
        flash('Введите значения через запятую', 'warning')
    
    return redirect(url_for('items.manage_item', item_id=item_id))

@items_bp.route('/item/<int:item_id>')
def manage_item(item_id):
    """Просмотр и управление значениями объекта"""
    item = Item.query.get_or_404(item_id)
    return render_template('item.html', item=item)

@items_bp.route('/item/delete/<int:item_id>', methods=['POST'])
def delete_item(item_id):
    """Удаление объекта"""
    item = Item.query.get_or_404(item_id)
    list_id = item.list_id
    if item.values:
        flash(f'Нельзя удалить объект "{item.name}" cо значениями', 'error')
    else:
        db.session.delete(item)
        db.session.commit()
        flash(f'Объект "{item.name}" успешно удален', 'success')
    return redirect(url_for('lists.view_list', list_id=list_id))

@items_bp.route('/value/delete/<int:value_id>', methods=['POST'])
def delete_value(value_id):
    """Удаление конкретного значения"""
    value = Value.query.get_or_404(value_id)
    item_id = value.item_id
    db.session.delete(value)
    db.session.commit()
    flash('Значение удалено', 'success')
    return redirect(url_for('items.manage_item', item_id=item_id))